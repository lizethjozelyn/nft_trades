import logo from './../logo.svg';

import Header from './../components/Header' 

function SearchBar(props) {
  return (
    <div className="searchbar">


    </div>
  );
}

export default SearchBar;